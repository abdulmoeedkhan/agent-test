// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyApodsyaDqBnsM19lJL4ZEYfORMAECtw7o",
    authDomain: "cordovaapp-a330b.firebaseapp.com",
    databaseURL: "https://cordovaapp-a330b-default-rtdb.firebaseio.com",
    projectId: "cordovaapp-a330b",
    storageBucket: "cordovaapp-a330b.appspot.com",
    messagingSenderId: "395337223344",
    appId: "1:395337223344:web:d1f840be8259f97ea73f75",
    measurementId: "G-KW34XWFBFJ",
    vapidKey: "BIFTqmB7TySF62lsn-agl-oX6eh6DOilNjADfHRdaItJbahorRWiL-Cvr97mDmEKRUqDKVHsvrw6rzjGcSaIyxA"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
