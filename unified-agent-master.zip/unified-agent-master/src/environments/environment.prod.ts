export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyApodsyaDqBnsM19lJL4ZEYfORMAECtw7o",
    authDomain: "cordovaapp-a330b.firebaseapp.com",
    databaseURL: "https://cordovaapp-a330b-default-rtdb.firebaseio.com",
    projectId: "cordovaapp-a330b",
    storageBucket: "cordovaapp-a330b.appspot.com",
    messagingSenderId: "395337223344",
    appId: "1:395337223344:web:d1f840be8259f97ea73f75",
    measurementId: "G-KW34XWFBFJ",
    vapidKey: "BIFTqmB7TySF62lsn-agl-oX6eh6DOilNjADfHRdaItJbahorRWiL-Cvr97mDmEKRUqDKVHsvrw6rzjGcSaIyxA"
  }
};
