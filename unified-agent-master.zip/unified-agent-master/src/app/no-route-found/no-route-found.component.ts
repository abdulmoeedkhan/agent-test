import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-no-route-found",
  templateUrl: "./no-route-found.component.html",
  styleUrls: ["./no-route-found.component.scss"]
})
export class NoRouteFoundComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
