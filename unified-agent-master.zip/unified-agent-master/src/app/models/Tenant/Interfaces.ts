export interface ITenant {}
