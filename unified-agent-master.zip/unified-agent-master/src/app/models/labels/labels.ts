export interface CustomerLabels {
    _id: string;
    name: string;
    colorCode: string;
    createdBy: string;
    createdAt: string;
    updatedAt: string;
    __v: number;
  }
