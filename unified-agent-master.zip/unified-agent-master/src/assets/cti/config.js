// var config =
// {
// 	domain: "finesse12-5.ucce.ipcc",
// 	boshUrl: "https://finesse12-5.ucce.ipcc:7443/http-bind/",
// 	finesseFlavor: "UCCE",
// 	callVariable: "callVariable1"
// }

// var callTypes =
// {
// 	inboundTypeCCE: "PREROUTE_ACD_IN",
// 	inboundTypeCCX: "ACD_IN",
// 	directType: "OTHER_IN",
// 	outboundType: "OUT",
// 	outboundType2: "AGENT_INSIDE",
// 	outboundCampaignType: "OUTBOUND",
// 	outboundPreviewCampaignTypeCCX: "OUTBOUND_DIRECT_PREVIEW",
// 	outboundPreviewCampaignTypeCCE: "OUTBOUND_PREVIEW",
// 	directTransferTypeCCE: "TRANSFER",
// 	directTransferTypeCCX: "OFFERED",
// 	consultType: "CONSULT",
// 	consultTransferTypeCCE: "CONSULT_OFFERED",
// 	consultTransferTypeCCX: "TRANSFER",
// 	conferenceType: "CONFERENCE",
// }

var config = {}
var callTypes = {}
var sipConfig = {}
